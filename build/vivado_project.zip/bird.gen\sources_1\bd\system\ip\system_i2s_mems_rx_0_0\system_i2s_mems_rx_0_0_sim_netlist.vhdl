-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
-- Date        : Sat Oct 17 17:05:56 2026
-- Host        : LAPTOP-EQILV9P4 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/Vivado/bird/bird.gen/sources_1/bd/system/ip/system_i2s_mems_rx_0_0/system_i2s_mems_rx_0_0_sim_netlist.vhdl
-- Design      : system_i2s_mems_rx_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_i2s_mems_rx_0_0_i2s_mems_rx is
  port (
    m_axis_tdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bclk_r_reg_0 : out STD_LOGIC;
    ws : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    sd : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of system_i2s_mems_rx_0_0_i2s_mems_rx : entity is "i2s_mems_rx";
end system_i2s_mems_rx_0_0_i2s_mems_rx;

architecture STRUCTURE of system_i2s_mems_rx_0_0_i2s_mems_rx is
  signal acc : STD_LOGIC_VECTOR ( 19 downto 1 );
  signal \acc_sum_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_1\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_2\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_3\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_4\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_5\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_6\ : STD_LOGIC;
  signal \acc_sum_carry__0_n_7\ : STD_LOGIC;
  signal \acc_sum_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_1\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_2\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_3\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_4\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_5\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_6\ : STD_LOGIC;
  signal \acc_sum_carry__1_n_7\ : STD_LOGIC;
  signal \acc_sum_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_1\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_2\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_3\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_4\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_5\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_6\ : STD_LOGIC;
  signal \acc_sum_carry__2_n_7\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_0\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_1\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_2\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_3\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_4\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_5\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_6\ : STD_LOGIC;
  signal \acc_sum_carry__3_n_7\ : STD_LOGIC;
  signal acc_sum_carry_i_1_n_0 : STD_LOGIC;
  signal acc_sum_carry_i_2_n_0 : STD_LOGIC;
  signal acc_sum_carry_n_0 : STD_LOGIC;
  signal acc_sum_carry_n_1 : STD_LOGIC;
  signal acc_sum_carry_n_2 : STD_LOGIC;
  signal acc_sum_carry_n_3 : STD_LOGIC;
  signal acc_sum_carry_n_4 : STD_LOGIC;
  signal acc_sum_carry_n_5 : STD_LOGIC;
  signal acc_sum_carry_n_6 : STD_LOGIC;
  signal acc_tick : STD_LOGIC;
  signal bclk_r_i_1_n_0 : STD_LOGIC;
  signal bclk_r_i_2_n_0 : STD_LOGIC;
  signal \^bclk_r_reg_0\ : STD_LOGIC;
  signal bclk_rise : STD_LOGIC;
  signal enq5_out : STD_LOGIC;
  signal enq_reg_n_0 : STD_LOGIC;
  signal m_axis_tvalid_INST_0_i_1_n_0 : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal \p_0_in__0\ : STD_LOGIC_VECTOR ( 4 to 4 );
  signal \p_0_in__1\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal p_1_in : STD_LOGIC;
  signal \p_1_in__0\ : STD_LOGIC;
  signal phase : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \phase[0]_i_1_n_0\ : STD_LOGIC;
  signal \phase[1]_i_1_n_0\ : STD_LOGIC;
  signal \phase[2]_i_1_n_0\ : STD_LOGIC;
  signal \phase[3]_i_1_n_0\ : STD_LOGIC;
  signal \phase[4]_i_1_n_0\ : STD_LOGIC;
  signal \phase[5]_i_2_n_0\ : STD_LOGIC;
  signal rdp0 : STD_LOGIC;
  signal \rdp[0]_i_1_n_0\ : STD_LOGIC;
  signal \rdp[1]_i_1_n_0\ : STD_LOGIC;
  signal \rdp[2]_i_1_n_0\ : STD_LOGIC;
  signal \rdp[3]_i_1_n_0\ : STD_LOGIC;
  signal \rdp_reg_n_0_[0]\ : STD_LOGIC;
  signal \rdp_reg_n_0_[1]\ : STD_LOGIC;
  signal \rdp_reg_n_0_[2]\ : STD_LOGIC;
  signal \rdp_reg_n_0_[3]\ : STD_LOGIC;
  signal shl : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal shl12_in : STD_LOGIC;
  signal shl_1 : STD_LOGIC;
  signal shr : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \shr[23]_i_2_n_0\ : STD_LOGIC;
  signal shr_0 : STD_LOGIC;
  signal wdata : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \wdata[31]_i_3_n_0\ : STD_LOGIC;
  signal \wdata[31]_i_4_n_0\ : STD_LOGIC;
  signal \wdata__0\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal wrp0 : STD_LOGIC;
  signal \wrp_reg_n_0_[0]\ : STD_LOGIC;
  signal \wrp_reg_n_0_[1]\ : STD_LOGIC;
  signal \wrp_reg_n_0_[2]\ : STD_LOGIC;
  signal \wrp_reg_n_0_[3]\ : STD_LOGIC;
  signal \^ws\ : STD_LOGIC;
  signal ws_r_i_1_n_0 : STD_LOGIC;
  signal ws_r_i_2_n_0 : STD_LOGIC;
  signal NLW_acc_sum_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_bclk_r_reg_i_3_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal NLW_bclk_r_reg_i_3_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_mem_reg_0_15_0_5_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_mem_reg_0_15_12_17_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_mem_reg_0_15_18_23_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_mem_reg_0_15_24_29_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_mem_reg_0_15_30_31_SPO_UNCONNECTED : STD_LOGIC;
  signal \NLW_mem_reg_0_15_30_31__0_SPO_UNCONNECTED\ : STD_LOGIC;
  signal NLW_mem_reg_0_15_6_11_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of mem_reg_0_15_0_5 : label is "";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of mem_reg_0_15_0_5 : label is 512;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of mem_reg_0_15_0_5 : label is "system_i2s_mems_rx_0_0/inst/mem_reg";
  attribute RTL_RAM_STYLE : string;
  attribute RTL_RAM_STYLE of mem_reg_0_15_0_5 : label is "auto";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of mem_reg_0_15_0_5 : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of mem_reg_0_15_0_5 : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of mem_reg_0_15_0_5 : label is 15;
  attribute ram_offset : integer;
  attribute ram_offset of mem_reg_0_15_0_5 : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of mem_reg_0_15_0_5 : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of mem_reg_0_15_0_5 : label is 5;
  attribute METHODOLOGY_DRC_VIOS of mem_reg_0_15_12_17 : label is "";
  attribute RTL_RAM_BITS of mem_reg_0_15_12_17 : label is 512;
  attribute RTL_RAM_NAME of mem_reg_0_15_12_17 : label is "system_i2s_mems_rx_0_0/inst/mem_reg";
  attribute RTL_RAM_STYLE of mem_reg_0_15_12_17 : label is "auto";
  attribute RTL_RAM_TYPE of mem_reg_0_15_12_17 : label is "RAM_SDP";
  attribute ram_addr_begin of mem_reg_0_15_12_17 : label is 0;
  attribute ram_addr_end of mem_reg_0_15_12_17 : label is 15;
  attribute ram_offset of mem_reg_0_15_12_17 : label is 0;
  attribute ram_slice_begin of mem_reg_0_15_12_17 : label is 12;
  attribute ram_slice_end of mem_reg_0_15_12_17 : label is 17;
  attribute METHODOLOGY_DRC_VIOS of mem_reg_0_15_18_23 : label is "";
  attribute RTL_RAM_BITS of mem_reg_0_15_18_23 : label is 512;
  attribute RTL_RAM_NAME of mem_reg_0_15_18_23 : label is "system_i2s_mems_rx_0_0/inst/mem_reg";
  attribute RTL_RAM_STYLE of mem_reg_0_15_18_23 : label is "auto";
  attribute RTL_RAM_TYPE of mem_reg_0_15_18_23 : label is "RAM_SDP";
  attribute ram_addr_begin of mem_reg_0_15_18_23 : label is 0;
  attribute ram_addr_end of mem_reg_0_15_18_23 : label is 15;
  attribute ram_offset of mem_reg_0_15_18_23 : label is 0;
  attribute ram_slice_begin of mem_reg_0_15_18_23 : label is 18;
  attribute ram_slice_end of mem_reg_0_15_18_23 : label is 23;
  attribute METHODOLOGY_DRC_VIOS of mem_reg_0_15_24_29 : label is "";
  attribute RTL_RAM_BITS of mem_reg_0_15_24_29 : label is 512;
  attribute RTL_RAM_NAME of mem_reg_0_15_24_29 : label is "system_i2s_mems_rx_0_0/inst/mem_reg";
  attribute RTL_RAM_STYLE of mem_reg_0_15_24_29 : label is "auto";
  attribute RTL_RAM_TYPE of mem_reg_0_15_24_29 : label is "RAM_SDP";
  attribute ram_addr_begin of mem_reg_0_15_24_29 : label is 0;
  attribute ram_addr_end of mem_reg_0_15_24_29 : label is 15;
  attribute ram_offset of mem_reg_0_15_24_29 : label is 0;
  attribute ram_slice_begin of mem_reg_0_15_24_29 : label is 24;
  attribute ram_slice_end of mem_reg_0_15_24_29 : label is 29;
  attribute METHODOLOGY_DRC_VIOS of mem_reg_0_15_30_31 : label is "";
  attribute RTL_RAM_BITS of mem_reg_0_15_30_31 : label is 512;
  attribute RTL_RAM_NAME of mem_reg_0_15_30_31 : label is "system_i2s_mems_rx_0_0/inst/mem_reg_0_15_30_31";
  attribute RTL_RAM_STYLE of mem_reg_0_15_30_31 : label is "NONE";
  attribute RTL_RAM_TYPE of mem_reg_0_15_30_31 : label is "RAM_SDP";
  attribute ram_addr_begin of mem_reg_0_15_30_31 : label is 0;
  attribute ram_addr_end of mem_reg_0_15_30_31 : label is 15;
  attribute ram_offset of mem_reg_0_15_30_31 : label is 0;
  attribute ram_slice_begin of mem_reg_0_15_30_31 : label is 30;
  attribute ram_slice_end of mem_reg_0_15_30_31 : label is 30;
  attribute METHODOLOGY_DRC_VIOS of \mem_reg_0_15_30_31__0\ : label is "";
  attribute RTL_RAM_BITS of \mem_reg_0_15_30_31__0\ : label is 512;
  attribute RTL_RAM_NAME of \mem_reg_0_15_30_31__0\ : label is "system_i2s_mems_rx_0_0/inst/mem_reg_0_15_30_31";
  attribute RTL_RAM_STYLE of \mem_reg_0_15_30_31__0\ : label is "NONE";
  attribute RTL_RAM_TYPE of \mem_reg_0_15_30_31__0\ : label is "RAM_SDP";
  attribute ram_addr_begin of \mem_reg_0_15_30_31__0\ : label is 0;
  attribute ram_addr_end of \mem_reg_0_15_30_31__0\ : label is 15;
  attribute ram_offset of \mem_reg_0_15_30_31__0\ : label is 0;
  attribute ram_slice_begin of \mem_reg_0_15_30_31__0\ : label is 31;
  attribute ram_slice_end of \mem_reg_0_15_30_31__0\ : label is 31;
  attribute METHODOLOGY_DRC_VIOS of mem_reg_0_15_6_11 : label is "";
  attribute RTL_RAM_BITS of mem_reg_0_15_6_11 : label is 512;
  attribute RTL_RAM_NAME of mem_reg_0_15_6_11 : label is "system_i2s_mems_rx_0_0/inst/mem_reg";
  attribute RTL_RAM_STYLE of mem_reg_0_15_6_11 : label is "auto";
  attribute RTL_RAM_TYPE of mem_reg_0_15_6_11 : label is "RAM_SDP";
  attribute ram_addr_begin of mem_reg_0_15_6_11 : label is 0;
  attribute ram_addr_end of mem_reg_0_15_6_11 : label is 15;
  attribute ram_offset of mem_reg_0_15_6_11 : label is 0;
  attribute ram_slice_begin of mem_reg_0_15_6_11 : label is 6;
  attribute ram_slice_end of mem_reg_0_15_6_11 : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \phase[0]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \phase[1]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \phase[2]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \phase[3]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \phase[4]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \rdp[1]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \rdp[2]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \rdp[3]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \rdp[4]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \shr[23]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \wdata[0]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \wdata[10]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \wdata[11]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \wdata[12]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \wdata[13]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \wdata[14]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \wdata[15]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \wdata[16]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \wdata[17]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \wdata[18]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \wdata[19]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \wdata[1]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \wdata[20]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \wdata[21]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \wdata[22]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \wdata[2]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \wdata[31]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \wdata[31]_i_3\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \wdata[3]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \wdata[4]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \wdata[5]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \wdata[6]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \wdata[7]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \wdata[8]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \wdata[9]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \wrp[1]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \wrp[2]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \wrp[3]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \wrp[4]_i_2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of ws_r_i_2 : label is "soft_lutpair0";
begin
  bclk_r_reg_0 <= \^bclk_r_reg_0\;
  ws <= \^ws\;
\acc_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__1_n_5\,
      Q => acc(10),
      R => bclk_r_i_1_n_0
    );
\acc_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__1_n_4\,
      Q => acc(11),
      R => bclk_r_i_1_n_0
    );
\acc_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__2_n_7\,
      Q => acc(12),
      R => bclk_r_i_1_n_0
    );
\acc_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__2_n_6\,
      Q => acc(13),
      R => bclk_r_i_1_n_0
    );
\acc_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__2_n_5\,
      Q => acc(14),
      R => bclk_r_i_1_n_0
    );
\acc_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__2_n_4\,
      Q => acc(15),
      R => bclk_r_i_1_n_0
    );
\acc_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__3_n_7\,
      Q => acc(16),
      R => bclk_r_i_1_n_0
    );
\acc_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__3_n_6\,
      Q => acc(17),
      R => bclk_r_i_1_n_0
    );
\acc_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__3_n_5\,
      Q => acc(18),
      R => bclk_r_i_1_n_0
    );
\acc_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__3_n_4\,
      Q => acc(19),
      R => bclk_r_i_1_n_0
    );
\acc_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc_sum_carry_n_6,
      Q => acc(1),
      R => bclk_r_i_1_n_0
    );
\acc_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc_sum_carry_n_5,
      Q => acc(2),
      R => bclk_r_i_1_n_0
    );
\acc_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc_sum_carry_n_4,
      Q => acc(3),
      R => bclk_r_i_1_n_0
    );
\acc_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__0_n_7\,
      Q => acc(4),
      R => bclk_r_i_1_n_0
    );
\acc_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__0_n_6\,
      Q => acc(5),
      R => bclk_r_i_1_n_0
    );
\acc_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__0_n_5\,
      Q => acc(6),
      R => bclk_r_i_1_n_0
    );
\acc_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__0_n_4\,
      Q => acc(7),
      R => bclk_r_i_1_n_0
    );
\acc_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__1_n_7\,
      Q => acc(8),
      R => bclk_r_i_1_n_0
    );
\acc_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \acc_sum_carry__1_n_6\,
      Q => acc(9),
      R => bclk_r_i_1_n_0
    );
acc_sum_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => acc_sum_carry_n_0,
      CO(2) => acc_sum_carry_n_1,
      CO(1) => acc_sum_carry_n_2,
      CO(0) => acc_sum_carry_n_3,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 1) => acc(2 downto 1),
      DI(0) => '0',
      O(3) => acc_sum_carry_n_4,
      O(2) => acc_sum_carry_n_5,
      O(1) => acc_sum_carry_n_6,
      O(0) => NLW_acc_sum_carry_O_UNCONNECTED(0),
      S(3) => acc(3),
      S(2) => acc_sum_carry_i_1_n_0,
      S(1) => acc_sum_carry_i_2_n_0,
      S(0) => '0'
    );
\acc_sum_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => acc_sum_carry_n_0,
      CO(3) => \acc_sum_carry__0_n_0\,
      CO(2) => \acc_sum_carry__0_n_1\,
      CO(1) => \acc_sum_carry__0_n_2\,
      CO(0) => \acc_sum_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => acc(7 downto 6),
      DI(1 downto 0) => B"00",
      O(3) => \acc_sum_carry__0_n_4\,
      O(2) => \acc_sum_carry__0_n_5\,
      O(1) => \acc_sum_carry__0_n_6\,
      O(0) => \acc_sum_carry__0_n_7\,
      S(3) => \acc_sum_carry__0_i_1_n_0\,
      S(2) => \acc_sum_carry__0_i_2_n_0\,
      S(1 downto 0) => acc(5 downto 4)
    );
\acc_sum_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(7),
      O => \acc_sum_carry__0_i_1_n_0\
    );
\acc_sum_carry__0_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(6),
      O => \acc_sum_carry__0_i_2_n_0\
    );
\acc_sum_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \acc_sum_carry__0_n_0\,
      CO(3) => \acc_sum_carry__1_n_0\,
      CO(2) => \acc_sum_carry__1_n_1\,
      CO(1) => \acc_sum_carry__1_n_2\,
      CO(0) => \acc_sum_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => acc(10 downto 8),
      O(3) => \acc_sum_carry__1_n_4\,
      O(2) => \acc_sum_carry__1_n_5\,
      O(1) => \acc_sum_carry__1_n_6\,
      O(0) => \acc_sum_carry__1_n_7\,
      S(3) => acc(11),
      S(2) => \acc_sum_carry__1_i_1_n_0\,
      S(1) => \acc_sum_carry__1_i_2_n_0\,
      S(0) => \acc_sum_carry__1_i_3_n_0\
    );
\acc_sum_carry__1_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(10),
      O => \acc_sum_carry__1_i_1_n_0\
    );
\acc_sum_carry__1_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(9),
      O => \acc_sum_carry__1_i_2_n_0\
    );
\acc_sum_carry__1_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(8),
      O => \acc_sum_carry__1_i_3_n_0\
    );
\acc_sum_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \acc_sum_carry__1_n_0\,
      CO(3) => \acc_sum_carry__2_n_0\,
      CO(2) => \acc_sum_carry__2_n_1\,
      CO(1) => \acc_sum_carry__2_n_2\,
      CO(0) => \acc_sum_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => acc(15),
      DI(2) => '0',
      DI(1) => acc(13),
      DI(0) => '0',
      O(3) => \acc_sum_carry__2_n_4\,
      O(2) => \acc_sum_carry__2_n_5\,
      O(1) => \acc_sum_carry__2_n_6\,
      O(0) => \acc_sum_carry__2_n_7\,
      S(3) => \acc_sum_carry__2_i_1_n_0\,
      S(2) => acc(14),
      S(1) => \acc_sum_carry__2_i_2_n_0\,
      S(0) => acc(12)
    );
\acc_sum_carry__2_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(15),
      O => \acc_sum_carry__2_i_1_n_0\
    );
\acc_sum_carry__2_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(13),
      O => \acc_sum_carry__2_i_2_n_0\
    );
\acc_sum_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \acc_sum_carry__2_n_0\,
      CO(3) => \acc_sum_carry__3_n_0\,
      CO(2) => \acc_sum_carry__3_n_1\,
      CO(1) => \acc_sum_carry__3_n_2\,
      CO(0) => \acc_sum_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \acc_sum_carry__3_n_4\,
      O(2) => \acc_sum_carry__3_n_5\,
      O(1) => \acc_sum_carry__3_n_6\,
      O(0) => \acc_sum_carry__3_n_7\,
      S(3 downto 0) => acc(19 downto 16)
    );
acc_sum_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(2),
      O => acc_sum_carry_i_1_n_0
    );
acc_sum_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => acc(1),
      O => acc_sum_carry_i_2_n_0
    );
bclk_r_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => bclk_r_i_1_n_0
    );
bclk_r_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => acc_tick,
      I1 => \^bclk_r_reg_0\,
      O => bclk_r_i_2_n_0
    );
bclk_r_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => bclk_r_i_2_n_0,
      Q => \^bclk_r_reg_0\,
      R => bclk_r_i_1_n_0
    );
bclk_r_reg_i_3: unisim.vcomponents.CARRY4
     port map (
      CI => \acc_sum_carry__3_n_0\,
      CO(3 downto 1) => NLW_bclk_r_reg_i_3_CO_UNCONNECTED(3 downto 1),
      CO(0) => acc_tick,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_bclk_r_reg_i_3_O_UNCONNECTED(3 downto 0),
      S(3 downto 0) => B"0001"
    );
enq_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => enq5_out,
      Q => enq_reg_n_0,
      R => bclk_r_i_1_n_0
    );
m_axis_tvalid_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7DFFFF7D"
    )
        port map (
      I0 => m_axis_tvalid_INST_0_i_1_n_0,
      I1 => p_0_in,
      I2 => \p_1_in__0\,
      I3 => \wrp_reg_n_0_[3]\,
      I4 => \rdp_reg_n_0_[3]\,
      O => m_axis_tvalid
    );
m_axis_tvalid_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \rdp_reg_n_0_[1]\,
      I1 => \wrp_reg_n_0_[1]\,
      I2 => \rdp_reg_n_0_[0]\,
      I3 => \wrp_reg_n_0_[0]\,
      I4 => \wrp_reg_n_0_[2]\,
      I5 => \rdp_reg_n_0_[2]\,
      O => m_axis_tvalid_INST_0_i_1_n_0
    );
mem_reg_0_15_0_5: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4) => '0',
      ADDRA(3) => \rdp_reg_n_0_[3]\,
      ADDRA(2) => \rdp_reg_n_0_[2]\,
      ADDRA(1) => \rdp_reg_n_0_[1]\,
      ADDRA(0) => \rdp_reg_n_0_[0]\,
      ADDRB(4) => '0',
      ADDRB(3) => \rdp_reg_n_0_[3]\,
      ADDRB(2) => \rdp_reg_n_0_[2]\,
      ADDRB(1) => \rdp_reg_n_0_[1]\,
      ADDRB(0) => \rdp_reg_n_0_[0]\,
      ADDRC(4) => '0',
      ADDRC(3) => \rdp_reg_n_0_[3]\,
      ADDRC(2) => \rdp_reg_n_0_[2]\,
      ADDRC(1) => \rdp_reg_n_0_[1]\,
      ADDRC(0) => \rdp_reg_n_0_[0]\,
      ADDRD(4) => '0',
      ADDRD(3) => \wrp_reg_n_0_[3]\,
      ADDRD(2) => \wrp_reg_n_0_[2]\,
      ADDRD(1) => \wrp_reg_n_0_[1]\,
      ADDRD(0) => \wrp_reg_n_0_[0]\,
      DIA(1 downto 0) => wdata(1 downto 0),
      DIB(1 downto 0) => wdata(3 downto 2),
      DIC(1 downto 0) => wdata(5 downto 4),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => m_axis_tdata(1 downto 0),
      DOB(1 downto 0) => m_axis_tdata(3 downto 2),
      DOC(1 downto 0) => m_axis_tdata(5 downto 4),
      DOD(1 downto 0) => NLW_mem_reg_0_15_0_5_DOD_UNCONNECTED(1 downto 0),
      WCLK => aclk,
      WE => p_1_in
    );
mem_reg_0_15_12_17: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4) => '0',
      ADDRA(3) => \rdp_reg_n_0_[3]\,
      ADDRA(2) => \rdp_reg_n_0_[2]\,
      ADDRA(1) => \rdp_reg_n_0_[1]\,
      ADDRA(0) => \rdp_reg_n_0_[0]\,
      ADDRB(4) => '0',
      ADDRB(3) => \rdp_reg_n_0_[3]\,
      ADDRB(2) => \rdp_reg_n_0_[2]\,
      ADDRB(1) => \rdp_reg_n_0_[1]\,
      ADDRB(0) => \rdp_reg_n_0_[0]\,
      ADDRC(4) => '0',
      ADDRC(3) => \rdp_reg_n_0_[3]\,
      ADDRC(2) => \rdp_reg_n_0_[2]\,
      ADDRC(1) => \rdp_reg_n_0_[1]\,
      ADDRC(0) => \rdp_reg_n_0_[0]\,
      ADDRD(4) => '0',
      ADDRD(3) => \wrp_reg_n_0_[3]\,
      ADDRD(2) => \wrp_reg_n_0_[2]\,
      ADDRD(1) => \wrp_reg_n_0_[1]\,
      ADDRD(0) => \wrp_reg_n_0_[0]\,
      DIA(1 downto 0) => wdata(13 downto 12),
      DIB(1 downto 0) => wdata(15 downto 14),
      DIC(1 downto 0) => wdata(17 downto 16),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => m_axis_tdata(13 downto 12),
      DOB(1 downto 0) => m_axis_tdata(15 downto 14),
      DOC(1 downto 0) => m_axis_tdata(17 downto 16),
      DOD(1 downto 0) => NLW_mem_reg_0_15_12_17_DOD_UNCONNECTED(1 downto 0),
      WCLK => aclk,
      WE => p_1_in
    );
mem_reg_0_15_18_23: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4) => '0',
      ADDRA(3) => \rdp_reg_n_0_[3]\,
      ADDRA(2) => \rdp_reg_n_0_[2]\,
      ADDRA(1) => \rdp_reg_n_0_[1]\,
      ADDRA(0) => \rdp_reg_n_0_[0]\,
      ADDRB(4) => '0',
      ADDRB(3) => \rdp_reg_n_0_[3]\,
      ADDRB(2) => \rdp_reg_n_0_[2]\,
      ADDRB(1) => \rdp_reg_n_0_[1]\,
      ADDRB(0) => \rdp_reg_n_0_[0]\,
      ADDRC(4) => '0',
      ADDRC(3) => \rdp_reg_n_0_[3]\,
      ADDRC(2) => \rdp_reg_n_0_[2]\,
      ADDRC(1) => \rdp_reg_n_0_[1]\,
      ADDRC(0) => \rdp_reg_n_0_[0]\,
      ADDRD(4) => '0',
      ADDRD(3) => \wrp_reg_n_0_[3]\,
      ADDRD(2) => \wrp_reg_n_0_[2]\,
      ADDRD(1) => \wrp_reg_n_0_[1]\,
      ADDRD(0) => \wrp_reg_n_0_[0]\,
      DIA(1 downto 0) => wdata(19 downto 18),
      DIB(1 downto 0) => wdata(21 downto 20),
      DIC(1) => wdata(31),
      DIC(0) => wdata(22),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => m_axis_tdata(19 downto 18),
      DOB(1 downto 0) => m_axis_tdata(21 downto 20),
      DOC(1 downto 0) => m_axis_tdata(23 downto 22),
      DOD(1 downto 0) => NLW_mem_reg_0_15_18_23_DOD_UNCONNECTED(1 downto 0),
      WCLK => aclk,
      WE => p_1_in
    );
mem_reg_0_15_24_29: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4) => '0',
      ADDRA(3) => \rdp_reg_n_0_[3]\,
      ADDRA(2) => \rdp_reg_n_0_[2]\,
      ADDRA(1) => \rdp_reg_n_0_[1]\,
      ADDRA(0) => \rdp_reg_n_0_[0]\,
      ADDRB(4) => '0',
      ADDRB(3) => \rdp_reg_n_0_[3]\,
      ADDRB(2) => \rdp_reg_n_0_[2]\,
      ADDRB(1) => \rdp_reg_n_0_[1]\,
      ADDRB(0) => \rdp_reg_n_0_[0]\,
      ADDRC(4) => '0',
      ADDRC(3) => \rdp_reg_n_0_[3]\,
      ADDRC(2) => \rdp_reg_n_0_[2]\,
      ADDRC(1) => \rdp_reg_n_0_[1]\,
      ADDRC(0) => \rdp_reg_n_0_[0]\,
      ADDRD(4) => '0',
      ADDRD(3) => \wrp_reg_n_0_[3]\,
      ADDRD(2) => \wrp_reg_n_0_[2]\,
      ADDRD(1) => \wrp_reg_n_0_[1]\,
      ADDRD(0) => \wrp_reg_n_0_[0]\,
      DIA(1) => wdata(31),
      DIA(0) => wdata(31),
      DIB(1) => wdata(31),
      DIB(0) => wdata(31),
      DIC(1) => wdata(31),
      DIC(0) => wdata(31),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => m_axis_tdata(25 downto 24),
      DOB(1 downto 0) => m_axis_tdata(27 downto 26),
      DOC(1 downto 0) => m_axis_tdata(29 downto 28),
      DOD(1 downto 0) => NLW_mem_reg_0_15_24_29_DOD_UNCONNECTED(1 downto 0),
      WCLK => aclk,
      WE => p_1_in
    );
mem_reg_0_15_30_31: unisim.vcomponents.RAM32X1D
     port map (
      A0 => \wrp_reg_n_0_[0]\,
      A1 => \wrp_reg_n_0_[1]\,
      A2 => \wrp_reg_n_0_[2]\,
      A3 => \wrp_reg_n_0_[3]\,
      A4 => '0',
      D => wdata(31),
      DPO => m_axis_tdata(30),
      DPRA0 => \rdp_reg_n_0_[0]\,
      DPRA1 => \rdp_reg_n_0_[1]\,
      DPRA2 => \rdp_reg_n_0_[2]\,
      DPRA3 => \rdp_reg_n_0_[3]\,
      DPRA4 => '0',
      SPO => NLW_mem_reg_0_15_30_31_SPO_UNCONNECTED,
      WCLK => aclk,
      WE => p_1_in
    );
\mem_reg_0_15_30_31__0\: unisim.vcomponents.RAM32X1D
     port map (
      A0 => \wrp_reg_n_0_[0]\,
      A1 => \wrp_reg_n_0_[1]\,
      A2 => \wrp_reg_n_0_[2]\,
      A3 => \wrp_reg_n_0_[3]\,
      A4 => '0',
      D => wdata(31),
      DPO => m_axis_tdata(31),
      DPRA0 => \rdp_reg_n_0_[0]\,
      DPRA1 => \rdp_reg_n_0_[1]\,
      DPRA2 => \rdp_reg_n_0_[2]\,
      DPRA3 => \rdp_reg_n_0_[3]\,
      DPRA4 => '0',
      SPO => \NLW_mem_reg_0_15_30_31__0_SPO_UNCONNECTED\,
      WCLK => aclk,
      WE => p_1_in
    );
mem_reg_0_15_30_31_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => wrp0,
      I1 => aresetn,
      O => p_1_in
    );
mem_reg_0_15_6_11: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4) => '0',
      ADDRA(3) => \rdp_reg_n_0_[3]\,
      ADDRA(2) => \rdp_reg_n_0_[2]\,
      ADDRA(1) => \rdp_reg_n_0_[1]\,
      ADDRA(0) => \rdp_reg_n_0_[0]\,
      ADDRB(4) => '0',
      ADDRB(3) => \rdp_reg_n_0_[3]\,
      ADDRB(2) => \rdp_reg_n_0_[2]\,
      ADDRB(1) => \rdp_reg_n_0_[1]\,
      ADDRB(0) => \rdp_reg_n_0_[0]\,
      ADDRC(4) => '0',
      ADDRC(3) => \rdp_reg_n_0_[3]\,
      ADDRC(2) => \rdp_reg_n_0_[2]\,
      ADDRC(1) => \rdp_reg_n_0_[1]\,
      ADDRC(0) => \rdp_reg_n_0_[0]\,
      ADDRD(4) => '0',
      ADDRD(3) => \wrp_reg_n_0_[3]\,
      ADDRD(2) => \wrp_reg_n_0_[2]\,
      ADDRD(1) => \wrp_reg_n_0_[1]\,
      ADDRD(0) => \wrp_reg_n_0_[0]\,
      DIA(1 downto 0) => wdata(7 downto 6),
      DIB(1 downto 0) => wdata(9 downto 8),
      DIC(1 downto 0) => wdata(11 downto 10),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => m_axis_tdata(7 downto 6),
      DOB(1 downto 0) => m_axis_tdata(9 downto 8),
      DOC(1 downto 0) => m_axis_tdata(11 downto 10),
      DOD(1 downto 0) => NLW_mem_reg_0_15_6_11_DOD_UNCONNECTED(1 downto 0),
      WCLK => aclk,
      WE => p_1_in
    );
\phase[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => phase(0),
      O => \phase[0]_i_1_n_0\
    );
\phase[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => phase(0),
      I1 => phase(1),
      O => \phase[1]_i_1_n_0\
    );
\phase[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6C"
    )
        port map (
      I0 => phase(0),
      I1 => phase(2),
      I2 => phase(1),
      O => \phase[2]_i_1_n_0\
    );
\phase[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6CCC"
    )
        port map (
      I0 => phase(0),
      I1 => phase(3),
      I2 => phase(2),
      I3 => phase(1),
      O => \phase[3]_i_1_n_0\
    );
\phase[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"78F0F0F0"
    )
        port map (
      I0 => phase(0),
      I1 => phase(3),
      I2 => phase(4),
      I3 => phase(2),
      I4 => phase(1),
      O => \phase[4]_i_1_n_0\
    );
\phase[5]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => \^bclk_r_reg_0\,
      I1 => acc_tick,
      O => bclk_rise
    );
\phase[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => phase(4),
      I1 => phase(2),
      I2 => phase(0),
      I3 => phase(1),
      I4 => phase(3),
      I5 => phase(5),
      O => \phase[5]_i_2_n_0\
    );
\phase_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => bclk_rise,
      D => \phase[0]_i_1_n_0\,
      Q => phase(0),
      R => bclk_r_i_1_n_0
    );
\phase_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => bclk_rise,
      D => \phase[1]_i_1_n_0\,
      Q => phase(1),
      R => bclk_r_i_1_n_0
    );
\phase_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => bclk_rise,
      D => \phase[2]_i_1_n_0\,
      Q => phase(2),
      R => bclk_r_i_1_n_0
    );
\phase_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => bclk_rise,
      D => \phase[3]_i_1_n_0\,
      Q => phase(3),
      R => bclk_r_i_1_n_0
    );
\phase_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => bclk_rise,
      D => \phase[4]_i_1_n_0\,
      Q => phase(4),
      R => bclk_r_i_1_n_0
    );
\phase_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => bclk_rise,
      D => \phase[5]_i_2_n_0\,
      Q => phase(5),
      R => bclk_r_i_1_n_0
    );
\rdp[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rdp_reg_n_0_[0]\,
      O => \rdp[0]_i_1_n_0\
    );
\rdp[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \rdp_reg_n_0_[0]\,
      I1 => \rdp_reg_n_0_[1]\,
      O => \rdp[1]_i_1_n_0\
    );
\rdp[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \rdp_reg_n_0_[0]\,
      I1 => \rdp_reg_n_0_[1]\,
      I2 => \rdp_reg_n_0_[2]\,
      O => \rdp[2]_i_1_n_0\
    );
\rdp[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \rdp_reg_n_0_[1]\,
      I1 => \rdp_reg_n_0_[0]\,
      I2 => \rdp_reg_n_0_[2]\,
      I3 => \rdp_reg_n_0_[3]\,
      O => \rdp[3]_i_1_n_0\
    );
\rdp[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6FF6FFFF00000000"
    )
        port map (
      I0 => \rdp_reg_n_0_[3]\,
      I1 => \wrp_reg_n_0_[3]\,
      I2 => \p_1_in__0\,
      I3 => p_0_in,
      I4 => m_axis_tvalid_INST_0_i_1_n_0,
      I5 => m_axis_tready,
      O => rdp0
    );
\rdp[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \rdp_reg_n_0_[2]\,
      I1 => \rdp_reg_n_0_[0]\,
      I2 => \rdp_reg_n_0_[1]\,
      I3 => \rdp_reg_n_0_[3]\,
      I4 => p_0_in,
      O => \p_0_in__0\(4)
    );
\rdp_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => rdp0,
      D => \rdp[0]_i_1_n_0\,
      Q => \rdp_reg_n_0_[0]\,
      R => bclk_r_i_1_n_0
    );
\rdp_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => rdp0,
      D => \rdp[1]_i_1_n_0\,
      Q => \rdp_reg_n_0_[1]\,
      R => bclk_r_i_1_n_0
    );
\rdp_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => rdp0,
      D => \rdp[2]_i_1_n_0\,
      Q => \rdp_reg_n_0_[2]\,
      R => bclk_r_i_1_n_0
    );
\rdp_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => rdp0,
      D => \rdp[3]_i_1_n_0\,
      Q => \rdp_reg_n_0_[3]\,
      R => bclk_r_i_1_n_0
    );
\rdp_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => rdp0,
      D => \p_0_in__0\(4),
      Q => p_0_in,
      R => bclk_r_i_1_n_0
    );
\shl[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000B000000000"
    )
        port map (
      I0 => \shr[23]_i_2_n_0\,
      I1 => phase(4),
      I2 => acc_tick,
      I3 => \^bclk_r_reg_0\,
      I4 => phase(5),
      I5 => shl12_in,
      O => shl_1
    );
\shl[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => phase(3),
      I1 => phase(4),
      I2 => phase(0),
      I3 => phase(5),
      I4 => phase(2),
      I5 => phase(1),
      O => shl12_in
    );
\shl_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => sd,
      Q => shl(0),
      R => bclk_r_i_1_n_0
    );
\shl_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(9),
      Q => shl(10),
      R => bclk_r_i_1_n_0
    );
\shl_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(10),
      Q => shl(11),
      R => bclk_r_i_1_n_0
    );
\shl_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(11),
      Q => shl(12),
      R => bclk_r_i_1_n_0
    );
\shl_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(12),
      Q => shl(13),
      R => bclk_r_i_1_n_0
    );
\shl_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(13),
      Q => shl(14),
      R => bclk_r_i_1_n_0
    );
\shl_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(14),
      Q => shl(15),
      R => bclk_r_i_1_n_0
    );
\shl_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(15),
      Q => shl(16),
      R => bclk_r_i_1_n_0
    );
\shl_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(16),
      Q => shl(17),
      R => bclk_r_i_1_n_0
    );
\shl_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(17),
      Q => shl(18),
      R => bclk_r_i_1_n_0
    );
\shl_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(18),
      Q => shl(19),
      R => bclk_r_i_1_n_0
    );
\shl_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(0),
      Q => shl(1),
      R => bclk_r_i_1_n_0
    );
\shl_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(19),
      Q => shl(20),
      R => bclk_r_i_1_n_0
    );
\shl_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(20),
      Q => shl(21),
      R => bclk_r_i_1_n_0
    );
\shl_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(21),
      Q => shl(22),
      R => bclk_r_i_1_n_0
    );
\shl_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(22),
      Q => shl(23),
      R => bclk_r_i_1_n_0
    );
\shl_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(1),
      Q => shl(2),
      R => bclk_r_i_1_n_0
    );
\shl_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(2),
      Q => shl(3),
      R => bclk_r_i_1_n_0
    );
\shl_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(3),
      Q => shl(4),
      R => bclk_r_i_1_n_0
    );
\shl_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(4),
      Q => shl(5),
      R => bclk_r_i_1_n_0
    );
\shl_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(5),
      Q => shl(6),
      R => bclk_r_i_1_n_0
    );
\shl_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(6),
      Q => shl(7),
      R => bclk_r_i_1_n_0
    );
\shl_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(7),
      Q => shl(8),
      R => bclk_r_i_1_n_0
    );
\shl_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shl_1,
      D => shl(8),
      Q => shl(9),
      R => bclk_r_i_1_n_0
    );
\shr[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0808000000080000"
    )
        port map (
      I0 => ws_r_i_2_n_0,
      I1 => acc_tick,
      I2 => \^bclk_r_reg_0\,
      I3 => phase(4),
      I4 => phase(5),
      I5 => \shr[23]_i_2_n_0\,
      O => shr_0
    );
\shr[23]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"01FF"
    )
        port map (
      I0 => phase(0),
      I1 => phase(1),
      I2 => phase(2),
      I3 => phase(3),
      O => \shr[23]_i_2_n_0\
    );
\shr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => sd,
      Q => shr(0),
      R => bclk_r_i_1_n_0
    );
\shr_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(9),
      Q => shr(10),
      R => bclk_r_i_1_n_0
    );
\shr_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(10),
      Q => shr(11),
      R => bclk_r_i_1_n_0
    );
\shr_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(11),
      Q => shr(12),
      R => bclk_r_i_1_n_0
    );
\shr_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(12),
      Q => shr(13),
      R => bclk_r_i_1_n_0
    );
\shr_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(13),
      Q => shr(14),
      R => bclk_r_i_1_n_0
    );
\shr_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(14),
      Q => shr(15),
      R => bclk_r_i_1_n_0
    );
\shr_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(15),
      Q => shr(16),
      R => bclk_r_i_1_n_0
    );
\shr_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(16),
      Q => shr(17),
      R => bclk_r_i_1_n_0
    );
\shr_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(17),
      Q => shr(18),
      R => bclk_r_i_1_n_0
    );
\shr_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(18),
      Q => shr(19),
      R => bclk_r_i_1_n_0
    );
\shr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(0),
      Q => shr(1),
      R => bclk_r_i_1_n_0
    );
\shr_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(19),
      Q => shr(20),
      R => bclk_r_i_1_n_0
    );
\shr_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(20),
      Q => shr(21),
      R => bclk_r_i_1_n_0
    );
\shr_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(21),
      Q => shr(22),
      R => bclk_r_i_1_n_0
    );
\shr_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(22),
      Q => shr(23),
      R => bclk_r_i_1_n_0
    );
\shr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(1),
      Q => shr(2),
      R => bclk_r_i_1_n_0
    );
\shr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(2),
      Q => shr(3),
      R => bclk_r_i_1_n_0
    );
\shr_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(3),
      Q => shr(4),
      R => bclk_r_i_1_n_0
    );
\shr_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(4),
      Q => shr(5),
      R => bclk_r_i_1_n_0
    );
\shr_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(5),
      Q => shr(6),
      R => bclk_r_i_1_n_0
    );
\shr_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(6),
      Q => shr(7),
      R => bclk_r_i_1_n_0
    );
\shr_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(7),
      Q => shr(8),
      R => bclk_r_i_1_n_0
    );
\shr_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => shr_0,
      D => shr(8),
      Q => shr(9),
      R => bclk_r_i_1_n_0
    );
\wdata[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(0),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(0),
      O => \wdata__0\(0)
    );
\wdata[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(10),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(10),
      O => \wdata__0\(10)
    );
\wdata[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(11),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(11),
      O => \wdata__0\(11)
    );
\wdata[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(12),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(12),
      O => \wdata__0\(12)
    );
\wdata[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(13),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(13),
      O => \wdata__0\(13)
    );
\wdata[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(14),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(14),
      O => \wdata__0\(14)
    );
\wdata[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(15),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(15),
      O => \wdata__0\(15)
    );
\wdata[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(16),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(16),
      O => \wdata__0\(16)
    );
\wdata[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(17),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(17),
      O => \wdata__0\(17)
    );
\wdata[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(18),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(18),
      O => \wdata__0\(18)
    );
\wdata[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(19),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(19),
      O => \wdata__0\(19)
    );
\wdata[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(1),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(1),
      O => \wdata__0\(1)
    );
\wdata[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(20),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(20),
      O => \wdata__0\(20)
    );
\wdata[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(21),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(21),
      O => \wdata__0\(21)
    );
\wdata[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(22),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(22),
      O => \wdata__0\(22)
    );
\wdata[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(2),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(2),
      O => \wdata__0\(2)
    );
\wdata[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000800000"
    )
        port map (
      I0 => phase(0),
      I1 => phase(3),
      I2 => phase(4),
      I3 => \wdata[31]_i_3_n_0\,
      I4 => acc_tick,
      I5 => \^bclk_r_reg_0\,
      O => enq5_out
    );
\wdata[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(23),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(23),
      O => \wdata__0\(31)
    );
\wdata[31]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => phase(1),
      I1 => phase(2),
      O => \wdata[31]_i_3_n_0\
    );
\wdata[31]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => phase(0),
      I1 => phase(3),
      I2 => phase(4),
      I3 => phase(5),
      I4 => phase(2),
      I5 => phase(1),
      O => \wdata[31]_i_4_n_0\
    );
\wdata[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(3),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(3),
      O => \wdata__0\(3)
    );
\wdata[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(4),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(4),
      O => \wdata__0\(4)
    );
\wdata[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(5),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(5),
      O => \wdata__0\(5)
    );
\wdata[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(6),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(6),
      O => \wdata__0\(6)
    );
\wdata[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(7),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(7),
      O => \wdata__0\(7)
    );
\wdata[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(8),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(8),
      O => \wdata__0\(8)
    );
\wdata[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => shr(9),
      I1 => \wdata[31]_i_4_n_0\,
      I2 => shl(9),
      O => \wdata__0\(9)
    );
\wdata_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(0),
      Q => wdata(0),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(10),
      Q => wdata(10),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(11),
      Q => wdata(11),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(12),
      Q => wdata(12),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(13),
      Q => wdata(13),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(14),
      Q => wdata(14),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(15),
      Q => wdata(15),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(16),
      Q => wdata(16),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(17),
      Q => wdata(17),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(18),
      Q => wdata(18),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(19),
      Q => wdata(19),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(1),
      Q => wdata(1),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(20),
      Q => wdata(20),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(21),
      Q => wdata(21),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(22),
      Q => wdata(22),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(2),
      Q => wdata(2),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(31),
      Q => wdata(31),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(3),
      Q => wdata(3),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(4),
      Q => wdata(4),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(5),
      Q => wdata(5),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(6),
      Q => wdata(6),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(7),
      Q => wdata(7),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(8),
      Q => wdata(8),
      R => bclk_r_i_1_n_0
    );
\wdata_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => enq5_out,
      D => \wdata__0\(9),
      Q => wdata(9),
      R => bclk_r_i_1_n_0
    );
\wrp[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \wrp_reg_n_0_[0]\,
      O => \p_0_in__1\(0)
    );
\wrp[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \wrp_reg_n_0_[0]\,
      I1 => \wrp_reg_n_0_[1]\,
      O => \p_0_in__1\(1)
    );
\wrp[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \wrp_reg_n_0_[0]\,
      I1 => \wrp_reg_n_0_[1]\,
      I2 => \wrp_reg_n_0_[2]\,
      O => \p_0_in__1\(2)
    );
\wrp[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \wrp_reg_n_0_[1]\,
      I1 => \wrp_reg_n_0_[0]\,
      I2 => \wrp_reg_n_0_[2]\,
      I3 => \wrp_reg_n_0_[3]\,
      O => \p_0_in__1\(3)
    );
\wrp[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA2AA22AA2AAAA"
    )
        port map (
      I0 => enq_reg_n_0,
      I1 => m_axis_tvalid_INST_0_i_1_n_0,
      I2 => \wrp_reg_n_0_[3]\,
      I3 => \rdp_reg_n_0_[3]\,
      I4 => \p_1_in__0\,
      I5 => p_0_in,
      O => wrp0
    );
\wrp[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \wrp_reg_n_0_[2]\,
      I1 => \wrp_reg_n_0_[0]\,
      I2 => \wrp_reg_n_0_[1]\,
      I3 => \wrp_reg_n_0_[3]\,
      I4 => \p_1_in__0\,
      O => \p_0_in__1\(4)
    );
\wrp_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => wrp0,
      D => \p_0_in__1\(0),
      Q => \wrp_reg_n_0_[0]\,
      R => bclk_r_i_1_n_0
    );
\wrp_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => wrp0,
      D => \p_0_in__1\(1),
      Q => \wrp_reg_n_0_[1]\,
      R => bclk_r_i_1_n_0
    );
\wrp_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => wrp0,
      D => \p_0_in__1\(2),
      Q => \wrp_reg_n_0_[2]\,
      R => bclk_r_i_1_n_0
    );
\wrp_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => wrp0,
      D => \p_0_in__1\(3),
      Q => \wrp_reg_n_0_[3]\,
      R => bclk_r_i_1_n_0
    );
\wrp_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => wrp0,
      D => \p_0_in__1\(4),
      Q => \p_1_in__0\,
      R => bclk_r_i_1_n_0
    );
ws_r_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888C8880888"
    )
        port map (
      I0 => \^ws\,
      I1 => aresetn,
      I2 => acc_tick,
      I3 => \^bclk_r_reg_0\,
      I4 => phase(5),
      I5 => ws_r_i_2_n_0,
      O => ws_r_i_1_n_0
    );
ws_r_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => phase(0),
      I1 => phase(4),
      I2 => phase(3),
      I3 => phase(2),
      I4 => phase(1),
      O => ws_r_i_2_n_0
    );
ws_r_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => ws_r_i_1_n_0,
      Q => \^ws\,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_i2s_mems_rx_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    bclk : out STD_LOGIC;
    ws : out STD_LOGIC;
    sd : in STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of system_i2s_mems_rx_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of system_i2s_mems_rx_0_0 : entity is "system_i2s_mems_rx_0_0,i2s_mems_rx,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of system_i2s_mems_rx_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of system_i2s_mems_rx_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of system_i2s_mems_rx_0_0 : entity is "i2s_mems_rx,Vivado 2026.1";
end system_i2s_mems_rx_0_0;

architecture STRUCTURE of system_i2s_mems_rx_0_0 is
  signal \<const0>\ : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of aclk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute X_INTERFACE_MODE of aresetn : signal is "slave";
  attribute X_INTERFACE_PARAMETER of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute X_INTERFACE_INFO of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute X_INTERFACE_INFO of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute X_INTERFACE_INFO of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute X_INTERFACE_MODE of m_axis_tdata : signal is "master";
  attribute X_INTERFACE_PARAMETER of m_axis_tdata : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 4, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 100000000, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, LAYERED_METADATA undef, INSERT_VIP 0";
begin
  m_axis_tlast <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.system_i2s_mems_rx_0_0_i2s_mems_rx
     port map (
      aclk => aclk,
      aresetn => aresetn,
      bclk_r_reg_0 => bclk,
      m_axis_tdata(31 downto 0) => m_axis_tdata(31 downto 0),
      m_axis_tready => m_axis_tready,
      m_axis_tvalid => m_axis_tvalid,
      sd => sd,
      ws => ws
    );
end STRUCTURE;
