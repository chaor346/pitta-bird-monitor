// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Sat Oct 17 17:05:56 2026
// Host        : LAPTOP-EQILV9P4 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/Vivado/bird/bird.gen/sources_1/bd/system/ip/system_i2s_mems_rx_0_0/system_i2s_mems_rx_0_0_sim_netlist.v
// Design      : system_i2s_mems_rx_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "system_i2s_mems_rx_0_0,i2s_mems_rx,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "i2s_mems_rx,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module system_i2s_mems_rx_0_0
   (aclk,
    aresetn,
    bclk,
    ws,
    sd,
    m_axis_tdata,
    m_axis_tvalid,
    m_axis_tready,
    m_axis_tlast);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *) input aclk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  output bclk;
  output ws;
  input sd;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) (* X_INTERFACE_MODE = "master" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 4, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 100000000, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, LAYERED_METADATA undef, INSERT_VIP 0" *) output [31:0]m_axis_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) output m_axis_tvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;

  wire \<const0> ;
  wire aclk;
  wire aresetn;
  wire bclk;
  wire [31:0]m_axis_tdata;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire sd;
  wire ws;

  assign m_axis_tlast = \<const0> ;
  GND GND
       (.G(\<const0> ));
  system_i2s_mems_rx_0_0_i2s_mems_rx inst
       (.aclk(aclk),
        .aresetn(aresetn),
        .bclk_r_reg_0(bclk),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid(m_axis_tvalid),
        .sd(sd),
        .ws(ws));
endmodule

(* ORIG_REF_NAME = "i2s_mems_rx" *) 
module system_i2s_mems_rx_0_0_i2s_mems_rx
   (m_axis_tdata,
    bclk_r_reg_0,
    ws,
    m_axis_tvalid,
    aclk,
    aresetn,
    sd,
    m_axis_tready);
  output [31:0]m_axis_tdata;
  output bclk_r_reg_0;
  output ws;
  output m_axis_tvalid;
  input aclk;
  input aresetn;
  input sd;
  input m_axis_tready;

  wire [19:1]acc;
  wire acc_sum_carry__0_i_1_n_0;
  wire acc_sum_carry__0_i_2_n_0;
  wire acc_sum_carry__0_n_0;
  wire acc_sum_carry__0_n_1;
  wire acc_sum_carry__0_n_2;
  wire acc_sum_carry__0_n_3;
  wire acc_sum_carry__0_n_4;
  wire acc_sum_carry__0_n_5;
  wire acc_sum_carry__0_n_6;
  wire acc_sum_carry__0_n_7;
  wire acc_sum_carry__1_i_1_n_0;
  wire acc_sum_carry__1_i_2_n_0;
  wire acc_sum_carry__1_i_3_n_0;
  wire acc_sum_carry__1_n_0;
  wire acc_sum_carry__1_n_1;
  wire acc_sum_carry__1_n_2;
  wire acc_sum_carry__1_n_3;
  wire acc_sum_carry__1_n_4;
  wire acc_sum_carry__1_n_5;
  wire acc_sum_carry__1_n_6;
  wire acc_sum_carry__1_n_7;
  wire acc_sum_carry__2_i_1_n_0;
  wire acc_sum_carry__2_i_2_n_0;
  wire acc_sum_carry__2_n_0;
  wire acc_sum_carry__2_n_1;
  wire acc_sum_carry__2_n_2;
  wire acc_sum_carry__2_n_3;
  wire acc_sum_carry__2_n_4;
  wire acc_sum_carry__2_n_5;
  wire acc_sum_carry__2_n_6;
  wire acc_sum_carry__2_n_7;
  wire acc_sum_carry__3_n_0;
  wire acc_sum_carry__3_n_1;
  wire acc_sum_carry__3_n_2;
  wire acc_sum_carry__3_n_3;
  wire acc_sum_carry__3_n_4;
  wire acc_sum_carry__3_n_5;
  wire acc_sum_carry__3_n_6;
  wire acc_sum_carry__3_n_7;
  wire acc_sum_carry_i_1_n_0;
  wire acc_sum_carry_i_2_n_0;
  wire acc_sum_carry_n_0;
  wire acc_sum_carry_n_1;
  wire acc_sum_carry_n_2;
  wire acc_sum_carry_n_3;
  wire acc_sum_carry_n_4;
  wire acc_sum_carry_n_5;
  wire acc_sum_carry_n_6;
  wire acc_tick;
  wire aclk;
  wire aresetn;
  wire bclk_r_i_1_n_0;
  wire bclk_r_i_2_n_0;
  wire bclk_r_reg_0;
  wire bclk_rise;
  wire enq5_out;
  wire enq_reg_n_0;
  wire [31:0]m_axis_tdata;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire m_axis_tvalid_INST_0_i_1_n_0;
  wire p_0_in;
  wire [4:4]p_0_in__0;
  wire [4:0]p_0_in__1;
  wire p_1_in;
  wire p_1_in__0;
  wire [5:0]phase;
  wire \phase[0]_i_1_n_0 ;
  wire \phase[1]_i_1_n_0 ;
  wire \phase[2]_i_1_n_0 ;
  wire \phase[3]_i_1_n_0 ;
  wire \phase[4]_i_1_n_0 ;
  wire \phase[5]_i_2_n_0 ;
  wire rdp0;
  wire \rdp[0]_i_1_n_0 ;
  wire \rdp[1]_i_1_n_0 ;
  wire \rdp[2]_i_1_n_0 ;
  wire \rdp[3]_i_1_n_0 ;
  wire \rdp_reg_n_0_[0] ;
  wire \rdp_reg_n_0_[1] ;
  wire \rdp_reg_n_0_[2] ;
  wire \rdp_reg_n_0_[3] ;
  wire sd;
  wire [23:0]shl;
  wire shl12_in;
  wire shl_1;
  wire [23:0]shr;
  wire \shr[23]_i_2_n_0 ;
  wire shr_0;
  wire [31:0]wdata;
  wire \wdata[31]_i_3_n_0 ;
  wire \wdata[31]_i_4_n_0 ;
  wire [31:0]wdata__0;
  wire wrp0;
  wire \wrp_reg_n_0_[0] ;
  wire \wrp_reg_n_0_[1] ;
  wire \wrp_reg_n_0_[2] ;
  wire \wrp_reg_n_0_[3] ;
  wire ws;
  wire ws_r_i_1_n_0;
  wire ws_r_i_2_n_0;
  wire [0:0]NLW_acc_sum_carry_O_UNCONNECTED;
  wire [3:1]NLW_bclk_r_reg_i_3_CO_UNCONNECTED;
  wire [3:0]NLW_bclk_r_reg_i_3_O_UNCONNECTED;
  wire [1:0]NLW_mem_reg_0_15_0_5_DOD_UNCONNECTED;
  wire [1:0]NLW_mem_reg_0_15_12_17_DOD_UNCONNECTED;
  wire [1:0]NLW_mem_reg_0_15_18_23_DOD_UNCONNECTED;
  wire [1:0]NLW_mem_reg_0_15_24_29_DOD_UNCONNECTED;
  wire NLW_mem_reg_0_15_30_31_SPO_UNCONNECTED;
  wire NLW_mem_reg_0_15_30_31__0_SPO_UNCONNECTED;
  wire [1:0]NLW_mem_reg_0_15_6_11_DOD_UNCONNECTED;

  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__1_n_5),
        .Q(acc[10]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__1_n_4),
        .Q(acc[11]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__2_n_7),
        .Q(acc[12]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__2_n_6),
        .Q(acc[13]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__2_n_5),
        .Q(acc[14]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__2_n_4),
        .Q(acc[15]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[16] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__3_n_7),
        .Q(acc[16]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[17] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__3_n_6),
        .Q(acc[17]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[18] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__3_n_5),
        .Q(acc[18]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[19] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__3_n_4),
        .Q(acc[19]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry_n_6),
        .Q(acc[1]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry_n_5),
        .Q(acc[2]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry_n_4),
        .Q(acc[3]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__0_n_7),
        .Q(acc[4]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__0_n_6),
        .Q(acc[5]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__0_n_5),
        .Q(acc[6]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__0_n_4),
        .Q(acc[7]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__1_n_7),
        .Q(acc[8]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \acc_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc_sum_carry__1_n_6),
        .Q(acc[9]),
        .R(bclk_r_i_1_n_0));
  CARRY4 acc_sum_carry
       (.CI(1'b0),
        .CO({acc_sum_carry_n_0,acc_sum_carry_n_1,acc_sum_carry_n_2,acc_sum_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,acc[2:1],1'b0}),
        .O({acc_sum_carry_n_4,acc_sum_carry_n_5,acc_sum_carry_n_6,NLW_acc_sum_carry_O_UNCONNECTED[0]}),
        .S({acc[3],acc_sum_carry_i_1_n_0,acc_sum_carry_i_2_n_0,1'b0}));
  CARRY4 acc_sum_carry__0
       (.CI(acc_sum_carry_n_0),
        .CO({acc_sum_carry__0_n_0,acc_sum_carry__0_n_1,acc_sum_carry__0_n_2,acc_sum_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({acc[7:6],1'b0,1'b0}),
        .O({acc_sum_carry__0_n_4,acc_sum_carry__0_n_5,acc_sum_carry__0_n_6,acc_sum_carry__0_n_7}),
        .S({acc_sum_carry__0_i_1_n_0,acc_sum_carry__0_i_2_n_0,acc[5:4]}));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry__0_i_1
       (.I0(acc[7]),
        .O(acc_sum_carry__0_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry__0_i_2
       (.I0(acc[6]),
        .O(acc_sum_carry__0_i_2_n_0));
  CARRY4 acc_sum_carry__1
       (.CI(acc_sum_carry__0_n_0),
        .CO({acc_sum_carry__1_n_0,acc_sum_carry__1_n_1,acc_sum_carry__1_n_2,acc_sum_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,acc[10:8]}),
        .O({acc_sum_carry__1_n_4,acc_sum_carry__1_n_5,acc_sum_carry__1_n_6,acc_sum_carry__1_n_7}),
        .S({acc[11],acc_sum_carry__1_i_1_n_0,acc_sum_carry__1_i_2_n_0,acc_sum_carry__1_i_3_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry__1_i_1
       (.I0(acc[10]),
        .O(acc_sum_carry__1_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry__1_i_2
       (.I0(acc[9]),
        .O(acc_sum_carry__1_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry__1_i_3
       (.I0(acc[8]),
        .O(acc_sum_carry__1_i_3_n_0));
  CARRY4 acc_sum_carry__2
       (.CI(acc_sum_carry__1_n_0),
        .CO({acc_sum_carry__2_n_0,acc_sum_carry__2_n_1,acc_sum_carry__2_n_2,acc_sum_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({acc[15],1'b0,acc[13],1'b0}),
        .O({acc_sum_carry__2_n_4,acc_sum_carry__2_n_5,acc_sum_carry__2_n_6,acc_sum_carry__2_n_7}),
        .S({acc_sum_carry__2_i_1_n_0,acc[14],acc_sum_carry__2_i_2_n_0,acc[12]}));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry__2_i_1
       (.I0(acc[15]),
        .O(acc_sum_carry__2_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry__2_i_2
       (.I0(acc[13]),
        .O(acc_sum_carry__2_i_2_n_0));
  CARRY4 acc_sum_carry__3
       (.CI(acc_sum_carry__2_n_0),
        .CO({acc_sum_carry__3_n_0,acc_sum_carry__3_n_1,acc_sum_carry__3_n_2,acc_sum_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({acc_sum_carry__3_n_4,acc_sum_carry__3_n_5,acc_sum_carry__3_n_6,acc_sum_carry__3_n_7}),
        .S(acc[19:16]));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry_i_1
       (.I0(acc[2]),
        .O(acc_sum_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    acc_sum_carry_i_2
       (.I0(acc[1]),
        .O(acc_sum_carry_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    bclk_r_i_1
       (.I0(aresetn),
        .O(bclk_r_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    bclk_r_i_2
       (.I0(acc_tick),
        .I1(bclk_r_reg_0),
        .O(bclk_r_i_2_n_0));
  FDRE #(
    .INIT(1'b0)) 
    bclk_r_reg
       (.C(aclk),
        .CE(1'b1),
        .D(bclk_r_i_2_n_0),
        .Q(bclk_r_reg_0),
        .R(bclk_r_i_1_n_0));
  CARRY4 bclk_r_reg_i_3
       (.CI(acc_sum_carry__3_n_0),
        .CO({NLW_bclk_r_reg_i_3_CO_UNCONNECTED[3:1],acc_tick}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_bclk_r_reg_i_3_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  FDRE #(
    .INIT(1'b0)) 
    enq_reg
       (.C(aclk),
        .CE(1'b1),
        .D(enq5_out),
        .Q(enq_reg_n_0),
        .R(bclk_r_i_1_n_0));
  LUT5 #(
    .INIT(32'h7DFFFF7D)) 
    m_axis_tvalid_INST_0
       (.I0(m_axis_tvalid_INST_0_i_1_n_0),
        .I1(p_0_in),
        .I2(p_1_in__0),
        .I3(\wrp_reg_n_0_[3] ),
        .I4(\rdp_reg_n_0_[3] ),
        .O(m_axis_tvalid));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    m_axis_tvalid_INST_0_i_1
       (.I0(\rdp_reg_n_0_[1] ),
        .I1(\wrp_reg_n_0_[1] ),
        .I2(\rdp_reg_n_0_[0] ),
        .I3(\wrp_reg_n_0_[0] ),
        .I4(\wrp_reg_n_0_[2] ),
        .I5(\rdp_reg_n_0_[2] ),
        .O(m_axis_tvalid_INST_0_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "512" *) 
  (* RTL_RAM_NAME = "system_i2s_mems_rx_0_0/inst/mem_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "5" *) 
  RAM32M mem_reg_0_15_0_5
       (.ADDRA({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRB({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRC({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRD({1'b0,\wrp_reg_n_0_[3] ,\wrp_reg_n_0_[2] ,\wrp_reg_n_0_[1] ,\wrp_reg_n_0_[0] }),
        .DIA(wdata[1:0]),
        .DIB(wdata[3:2]),
        .DIC(wdata[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(m_axis_tdata[1:0]),
        .DOB(m_axis_tdata[3:2]),
        .DOC(m_axis_tdata[5:4]),
        .DOD(NLW_mem_reg_0_15_0_5_DOD_UNCONNECTED[1:0]),
        .WCLK(aclk),
        .WE(p_1_in));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "512" *) 
  (* RTL_RAM_NAME = "system_i2s_mems_rx_0_0/inst/mem_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "17" *) 
  RAM32M mem_reg_0_15_12_17
       (.ADDRA({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRB({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRC({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRD({1'b0,\wrp_reg_n_0_[3] ,\wrp_reg_n_0_[2] ,\wrp_reg_n_0_[1] ,\wrp_reg_n_0_[0] }),
        .DIA(wdata[13:12]),
        .DIB(wdata[15:14]),
        .DIC(wdata[17:16]),
        .DID({1'b0,1'b0}),
        .DOA(m_axis_tdata[13:12]),
        .DOB(m_axis_tdata[15:14]),
        .DOC(m_axis_tdata[17:16]),
        .DOD(NLW_mem_reg_0_15_12_17_DOD_UNCONNECTED[1:0]),
        .WCLK(aclk),
        .WE(p_1_in));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "512" *) 
  (* RTL_RAM_NAME = "system_i2s_mems_rx_0_0/inst/mem_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "23" *) 
  RAM32M mem_reg_0_15_18_23
       (.ADDRA({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRB({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRC({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRD({1'b0,\wrp_reg_n_0_[3] ,\wrp_reg_n_0_[2] ,\wrp_reg_n_0_[1] ,\wrp_reg_n_0_[0] }),
        .DIA(wdata[19:18]),
        .DIB(wdata[21:20]),
        .DIC({wdata[31],wdata[22]}),
        .DID({1'b0,1'b0}),
        .DOA(m_axis_tdata[19:18]),
        .DOB(m_axis_tdata[21:20]),
        .DOC(m_axis_tdata[23:22]),
        .DOD(NLW_mem_reg_0_15_18_23_DOD_UNCONNECTED[1:0]),
        .WCLK(aclk),
        .WE(p_1_in));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "512" *) 
  (* RTL_RAM_NAME = "system_i2s_mems_rx_0_0/inst/mem_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "24" *) 
  (* ram_slice_end = "29" *) 
  RAM32M mem_reg_0_15_24_29
       (.ADDRA({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRB({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRC({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRD({1'b0,\wrp_reg_n_0_[3] ,\wrp_reg_n_0_[2] ,\wrp_reg_n_0_[1] ,\wrp_reg_n_0_[0] }),
        .DIA({wdata[31],wdata[31]}),
        .DIB({wdata[31],wdata[31]}),
        .DIC({wdata[31],wdata[31]}),
        .DID({1'b0,1'b0}),
        .DOA(m_axis_tdata[25:24]),
        .DOB(m_axis_tdata[27:26]),
        .DOC(m_axis_tdata[29:28]),
        .DOD(NLW_mem_reg_0_15_24_29_DOD_UNCONNECTED[1:0]),
        .WCLK(aclk),
        .WE(p_1_in));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "512" *) 
  (* RTL_RAM_NAME = "system_i2s_mems_rx_0_0/inst/mem_reg_0_15_30_31" *) 
  (* RTL_RAM_STYLE = "NONE" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "30" *) 
  (* ram_slice_end = "30" *) 
  RAM32X1D mem_reg_0_15_30_31
       (.A0(\wrp_reg_n_0_[0] ),
        .A1(\wrp_reg_n_0_[1] ),
        .A2(\wrp_reg_n_0_[2] ),
        .A3(\wrp_reg_n_0_[3] ),
        .A4(1'b0),
        .D(wdata[31]),
        .DPO(m_axis_tdata[30]),
        .DPRA0(\rdp_reg_n_0_[0] ),
        .DPRA1(\rdp_reg_n_0_[1] ),
        .DPRA2(\rdp_reg_n_0_[2] ),
        .DPRA3(\rdp_reg_n_0_[3] ),
        .DPRA4(1'b0),
        .SPO(NLW_mem_reg_0_15_30_31_SPO_UNCONNECTED),
        .WCLK(aclk),
        .WE(p_1_in));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "512" *) 
  (* RTL_RAM_NAME = "system_i2s_mems_rx_0_0/inst/mem_reg_0_15_30_31" *) 
  (* RTL_RAM_STYLE = "NONE" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "31" *) 
  (* ram_slice_end = "31" *) 
  RAM32X1D mem_reg_0_15_30_31__0
       (.A0(\wrp_reg_n_0_[0] ),
        .A1(\wrp_reg_n_0_[1] ),
        .A2(\wrp_reg_n_0_[2] ),
        .A3(\wrp_reg_n_0_[3] ),
        .A4(1'b0),
        .D(wdata[31]),
        .DPO(m_axis_tdata[31]),
        .DPRA0(\rdp_reg_n_0_[0] ),
        .DPRA1(\rdp_reg_n_0_[1] ),
        .DPRA2(\rdp_reg_n_0_[2] ),
        .DPRA3(\rdp_reg_n_0_[3] ),
        .DPRA4(1'b0),
        .SPO(NLW_mem_reg_0_15_30_31__0_SPO_UNCONNECTED),
        .WCLK(aclk),
        .WE(p_1_in));
  LUT2 #(
    .INIT(4'h8)) 
    mem_reg_0_15_30_31_i_1
       (.I0(wrp0),
        .I1(aresetn),
        .O(p_1_in));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "512" *) 
  (* RTL_RAM_NAME = "system_i2s_mems_rx_0_0/inst/mem_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "11" *) 
  RAM32M mem_reg_0_15_6_11
       (.ADDRA({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRB({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRC({1'b0,\rdp_reg_n_0_[3] ,\rdp_reg_n_0_[2] ,\rdp_reg_n_0_[1] ,\rdp_reg_n_0_[0] }),
        .ADDRD({1'b0,\wrp_reg_n_0_[3] ,\wrp_reg_n_0_[2] ,\wrp_reg_n_0_[1] ,\wrp_reg_n_0_[0] }),
        .DIA(wdata[7:6]),
        .DIB(wdata[9:8]),
        .DIC(wdata[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(m_axis_tdata[7:6]),
        .DOB(m_axis_tdata[9:8]),
        .DOC(m_axis_tdata[11:10]),
        .DOD(NLW_mem_reg_0_15_6_11_DOD_UNCONNECTED[1:0]),
        .WCLK(aclk),
        .WE(p_1_in));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \phase[0]_i_1 
       (.I0(phase[0]),
        .O(\phase[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \phase[1]_i_1 
       (.I0(phase[0]),
        .I1(phase[1]),
        .O(\phase[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'h6C)) 
    \phase[2]_i_1 
       (.I0(phase[0]),
        .I1(phase[2]),
        .I2(phase[1]),
        .O(\phase[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h6CCC)) 
    \phase[3]_i_1 
       (.I0(phase[0]),
        .I1(phase[3]),
        .I2(phase[2]),
        .I3(phase[1]),
        .O(\phase[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h78F0F0F0)) 
    \phase[4]_i_1 
       (.I0(phase[0]),
        .I1(phase[3]),
        .I2(phase[4]),
        .I3(phase[2]),
        .I4(phase[1]),
        .O(\phase[4]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h4)) 
    \phase[5]_i_1 
       (.I0(bclk_r_reg_0),
        .I1(acc_tick),
        .O(bclk_rise));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \phase[5]_i_2 
       (.I0(phase[4]),
        .I1(phase[2]),
        .I2(phase[0]),
        .I3(phase[1]),
        .I4(phase[3]),
        .I5(phase[5]),
        .O(\phase[5]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \phase_reg[0] 
       (.C(aclk),
        .CE(bclk_rise),
        .D(\phase[0]_i_1_n_0 ),
        .Q(phase[0]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \phase_reg[1] 
       (.C(aclk),
        .CE(bclk_rise),
        .D(\phase[1]_i_1_n_0 ),
        .Q(phase[1]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \phase_reg[2] 
       (.C(aclk),
        .CE(bclk_rise),
        .D(\phase[2]_i_1_n_0 ),
        .Q(phase[2]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \phase_reg[3] 
       (.C(aclk),
        .CE(bclk_rise),
        .D(\phase[3]_i_1_n_0 ),
        .Q(phase[3]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \phase_reg[4] 
       (.C(aclk),
        .CE(bclk_rise),
        .D(\phase[4]_i_1_n_0 ),
        .Q(phase[4]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \phase_reg[5] 
       (.C(aclk),
        .CE(bclk_rise),
        .D(\phase[5]_i_2_n_0 ),
        .Q(phase[5]),
        .R(bclk_r_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \rdp[0]_i_1 
       (.I0(\rdp_reg_n_0_[0] ),
        .O(\rdp[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \rdp[1]_i_1 
       (.I0(\rdp_reg_n_0_[0] ),
        .I1(\rdp_reg_n_0_[1] ),
        .O(\rdp[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \rdp[2]_i_1 
       (.I0(\rdp_reg_n_0_[0] ),
        .I1(\rdp_reg_n_0_[1] ),
        .I2(\rdp_reg_n_0_[2] ),
        .O(\rdp[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \rdp[3]_i_1 
       (.I0(\rdp_reg_n_0_[1] ),
        .I1(\rdp_reg_n_0_[0] ),
        .I2(\rdp_reg_n_0_[2] ),
        .I3(\rdp_reg_n_0_[3] ),
        .O(\rdp[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h6FF6FFFF00000000)) 
    \rdp[4]_i_1 
       (.I0(\rdp_reg_n_0_[3] ),
        .I1(\wrp_reg_n_0_[3] ),
        .I2(p_1_in__0),
        .I3(p_0_in),
        .I4(m_axis_tvalid_INST_0_i_1_n_0),
        .I5(m_axis_tready),
        .O(rdp0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \rdp[4]_i_2 
       (.I0(\rdp_reg_n_0_[2] ),
        .I1(\rdp_reg_n_0_[0] ),
        .I2(\rdp_reg_n_0_[1] ),
        .I3(\rdp_reg_n_0_[3] ),
        .I4(p_0_in),
        .O(p_0_in__0));
  FDRE #(
    .INIT(1'b0)) 
    \rdp_reg[0] 
       (.C(aclk),
        .CE(rdp0),
        .D(\rdp[0]_i_1_n_0 ),
        .Q(\rdp_reg_n_0_[0] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \rdp_reg[1] 
       (.C(aclk),
        .CE(rdp0),
        .D(\rdp[1]_i_1_n_0 ),
        .Q(\rdp_reg_n_0_[1] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \rdp_reg[2] 
       (.C(aclk),
        .CE(rdp0),
        .D(\rdp[2]_i_1_n_0 ),
        .Q(\rdp_reg_n_0_[2] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \rdp_reg[3] 
       (.C(aclk),
        .CE(rdp0),
        .D(\rdp[3]_i_1_n_0 ),
        .Q(\rdp_reg_n_0_[3] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \rdp_reg[4] 
       (.C(aclk),
        .CE(rdp0),
        .D(p_0_in__0),
        .Q(p_0_in),
        .R(bclk_r_i_1_n_0));
  LUT6 #(
    .INIT(64'h000000B000000000)) 
    \shl[23]_i_1 
       (.I0(\shr[23]_i_2_n_0 ),
        .I1(phase[4]),
        .I2(acc_tick),
        .I3(bclk_r_reg_0),
        .I4(phase[5]),
        .I5(shl12_in),
        .O(shl_1));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \shl[23]_i_2 
       (.I0(phase[3]),
        .I1(phase[4]),
        .I2(phase[0]),
        .I3(phase[5]),
        .I4(phase[2]),
        .I5(phase[1]),
        .O(shl12_in));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[0] 
       (.C(aclk),
        .CE(shl_1),
        .D(sd),
        .Q(shl[0]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[10] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[9]),
        .Q(shl[10]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[11] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[10]),
        .Q(shl[11]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[12] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[11]),
        .Q(shl[12]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[13] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[12]),
        .Q(shl[13]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[14] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[13]),
        .Q(shl[14]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[15] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[14]),
        .Q(shl[15]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[16] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[15]),
        .Q(shl[16]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[17] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[16]),
        .Q(shl[17]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[18] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[17]),
        .Q(shl[18]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[19] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[18]),
        .Q(shl[19]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[1] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[0]),
        .Q(shl[1]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[20] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[19]),
        .Q(shl[20]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[21] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[20]),
        .Q(shl[21]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[22] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[21]),
        .Q(shl[22]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[23] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[22]),
        .Q(shl[23]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[2] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[1]),
        .Q(shl[2]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[3] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[2]),
        .Q(shl[3]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[4] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[3]),
        .Q(shl[4]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[5] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[4]),
        .Q(shl[5]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[6] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[5]),
        .Q(shl[6]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[7] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[6]),
        .Q(shl[7]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[8] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[7]),
        .Q(shl[8]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shl_reg[9] 
       (.C(aclk),
        .CE(shl_1),
        .D(shl[8]),
        .Q(shl[9]),
        .R(bclk_r_i_1_n_0));
  LUT6 #(
    .INIT(64'h0808000000080000)) 
    \shr[23]_i_1 
       (.I0(ws_r_i_2_n_0),
        .I1(acc_tick),
        .I2(bclk_r_reg_0),
        .I3(phase[4]),
        .I4(phase[5]),
        .I5(\shr[23]_i_2_n_0 ),
        .O(shr_0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h01FF)) 
    \shr[23]_i_2 
       (.I0(phase[0]),
        .I1(phase[1]),
        .I2(phase[2]),
        .I3(phase[3]),
        .O(\shr[23]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[0] 
       (.C(aclk),
        .CE(shr_0),
        .D(sd),
        .Q(shr[0]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[10] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[9]),
        .Q(shr[10]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[11] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[10]),
        .Q(shr[11]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[12] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[11]),
        .Q(shr[12]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[13] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[12]),
        .Q(shr[13]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[14] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[13]),
        .Q(shr[14]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[15] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[14]),
        .Q(shr[15]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[16] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[15]),
        .Q(shr[16]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[17] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[16]),
        .Q(shr[17]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[18] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[17]),
        .Q(shr[18]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[19] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[18]),
        .Q(shr[19]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[1] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[0]),
        .Q(shr[1]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[20] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[19]),
        .Q(shr[20]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[21] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[20]),
        .Q(shr[21]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[22] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[21]),
        .Q(shr[22]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[23] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[22]),
        .Q(shr[23]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[2] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[1]),
        .Q(shr[2]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[3] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[2]),
        .Q(shr[3]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[4] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[3]),
        .Q(shr[4]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[5] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[4]),
        .Q(shr[5]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[6] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[5]),
        .Q(shr[6]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[7] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[6]),
        .Q(shr[7]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[8] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[7]),
        .Q(shr[8]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \shr_reg[9] 
       (.C(aclk),
        .CE(shr_0),
        .D(shr[8]),
        .Q(shr[9]),
        .R(bclk_r_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[0]_i_1 
       (.I0(shr[0]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[0]),
        .O(wdata__0[0]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[10]_i_1 
       (.I0(shr[10]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[10]),
        .O(wdata__0[10]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[11]_i_1 
       (.I0(shr[11]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[11]),
        .O(wdata__0[11]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[12]_i_1 
       (.I0(shr[12]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[12]),
        .O(wdata__0[12]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[13]_i_1 
       (.I0(shr[13]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[13]),
        .O(wdata__0[13]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[14]_i_1 
       (.I0(shr[14]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[14]),
        .O(wdata__0[14]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[15]_i_1 
       (.I0(shr[15]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[15]),
        .O(wdata__0[15]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[16]_i_1 
       (.I0(shr[16]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[16]),
        .O(wdata__0[16]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[17]_i_1 
       (.I0(shr[17]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[17]),
        .O(wdata__0[17]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[18]_i_1 
       (.I0(shr[18]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[18]),
        .O(wdata__0[18]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[19]_i_1 
       (.I0(shr[19]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[19]),
        .O(wdata__0[19]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[1]_i_1 
       (.I0(shr[1]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[1]),
        .O(wdata__0[1]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[20]_i_1 
       (.I0(shr[20]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[20]),
        .O(wdata__0[20]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[21]_i_1 
       (.I0(shr[21]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[21]),
        .O(wdata__0[21]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[22]_i_1 
       (.I0(shr[22]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[22]),
        .O(wdata__0[22]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[2]_i_1 
       (.I0(shr[2]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[2]),
        .O(wdata__0[2]));
  LUT6 #(
    .INIT(64'h0000000000800000)) 
    \wdata[31]_i_1 
       (.I0(phase[0]),
        .I1(phase[3]),
        .I2(phase[4]),
        .I3(\wdata[31]_i_3_n_0 ),
        .I4(acc_tick),
        .I5(bclk_r_reg_0),
        .O(enq5_out));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[31]_i_2 
       (.I0(shr[23]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[23]),
        .O(wdata__0[31]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \wdata[31]_i_3 
       (.I0(phase[1]),
        .I1(phase[2]),
        .O(\wdata[31]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \wdata[31]_i_4 
       (.I0(phase[0]),
        .I1(phase[3]),
        .I2(phase[4]),
        .I3(phase[5]),
        .I4(phase[2]),
        .I5(phase[1]),
        .O(\wdata[31]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[3]_i_1 
       (.I0(shr[3]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[3]),
        .O(wdata__0[3]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[4]_i_1 
       (.I0(shr[4]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[4]),
        .O(wdata__0[4]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[5]_i_1 
       (.I0(shr[5]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[5]),
        .O(wdata__0[5]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[6]_i_1 
       (.I0(shr[6]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[6]),
        .O(wdata__0[6]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[7]_i_1 
       (.I0(shr[7]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[7]),
        .O(wdata__0[7]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[8]_i_1 
       (.I0(shr[8]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[8]),
        .O(wdata__0[8]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \wdata[9]_i_1 
       (.I0(shr[9]),
        .I1(\wdata[31]_i_4_n_0 ),
        .I2(shl[9]),
        .O(wdata__0[9]));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[0] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[0]),
        .Q(wdata[0]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[10] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[10]),
        .Q(wdata[10]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[11] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[11]),
        .Q(wdata[11]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[12] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[12]),
        .Q(wdata[12]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[13] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[13]),
        .Q(wdata[13]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[14] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[14]),
        .Q(wdata[14]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[15] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[15]),
        .Q(wdata[15]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[16] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[16]),
        .Q(wdata[16]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[17] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[17]),
        .Q(wdata[17]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[18] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[18]),
        .Q(wdata[18]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[19] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[19]),
        .Q(wdata[19]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[1] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[1]),
        .Q(wdata[1]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[20] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[20]),
        .Q(wdata[20]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[21] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[21]),
        .Q(wdata[21]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[22] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[22]),
        .Q(wdata[22]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[2] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[2]),
        .Q(wdata[2]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[31] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[31]),
        .Q(wdata[31]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[3] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[3]),
        .Q(wdata[3]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[4] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[4]),
        .Q(wdata[4]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[5] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[5]),
        .Q(wdata[5]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[6] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[6]),
        .Q(wdata[6]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[7] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[7]),
        .Q(wdata[7]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[8] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[8]),
        .Q(wdata[8]),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wdata_reg[9] 
       (.C(aclk),
        .CE(enq5_out),
        .D(wdata__0[9]),
        .Q(wdata[9]),
        .R(bclk_r_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \wrp[0]_i_1 
       (.I0(\wrp_reg_n_0_[0] ),
        .O(p_0_in__1[0]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \wrp[1]_i_1 
       (.I0(\wrp_reg_n_0_[0] ),
        .I1(\wrp_reg_n_0_[1] ),
        .O(p_0_in__1[1]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \wrp[2]_i_1 
       (.I0(\wrp_reg_n_0_[0] ),
        .I1(\wrp_reg_n_0_[1] ),
        .I2(\wrp_reg_n_0_[2] ),
        .O(p_0_in__1[2]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \wrp[3]_i_1 
       (.I0(\wrp_reg_n_0_[1] ),
        .I1(\wrp_reg_n_0_[0] ),
        .I2(\wrp_reg_n_0_[2] ),
        .I3(\wrp_reg_n_0_[3] ),
        .O(p_0_in__1[3]));
  LUT6 #(
    .INIT(64'hAAAA2AA22AA2AAAA)) 
    \wrp[4]_i_1 
       (.I0(enq_reg_n_0),
        .I1(m_axis_tvalid_INST_0_i_1_n_0),
        .I2(\wrp_reg_n_0_[3] ),
        .I3(\rdp_reg_n_0_[3] ),
        .I4(p_1_in__0),
        .I5(p_0_in),
        .O(wrp0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \wrp[4]_i_2 
       (.I0(\wrp_reg_n_0_[2] ),
        .I1(\wrp_reg_n_0_[0] ),
        .I2(\wrp_reg_n_0_[1] ),
        .I3(\wrp_reg_n_0_[3] ),
        .I4(p_1_in__0),
        .O(p_0_in__1[4]));
  FDRE #(
    .INIT(1'b0)) 
    \wrp_reg[0] 
       (.C(aclk),
        .CE(wrp0),
        .D(p_0_in__1[0]),
        .Q(\wrp_reg_n_0_[0] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wrp_reg[1] 
       (.C(aclk),
        .CE(wrp0),
        .D(p_0_in__1[1]),
        .Q(\wrp_reg_n_0_[1] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wrp_reg[2] 
       (.C(aclk),
        .CE(wrp0),
        .D(p_0_in__1[2]),
        .Q(\wrp_reg_n_0_[2] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wrp_reg[3] 
       (.C(aclk),
        .CE(wrp0),
        .D(p_0_in__1[3]),
        .Q(\wrp_reg_n_0_[3] ),
        .R(bclk_r_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \wrp_reg[4] 
       (.C(aclk),
        .CE(wrp0),
        .D(p_0_in__1[4]),
        .Q(p_1_in__0),
        .R(bclk_r_i_1_n_0));
  LUT6 #(
    .INIT(64'h88888888C8880888)) 
    ws_r_i_1
       (.I0(ws),
        .I1(aresetn),
        .I2(acc_tick),
        .I3(bclk_r_reg_0),
        .I4(phase[5]),
        .I5(ws_r_i_2_n_0),
        .O(ws_r_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    ws_r_i_2
       (.I0(phase[0]),
        .I1(phase[4]),
        .I2(phase[3]),
        .I3(phase[2]),
        .I4(phase[1]),
        .O(ws_r_i_2_n_0));
  FDRE #(
    .INIT(1'b0)) 
    ws_r_reg
       (.C(aclk),
        .CE(1'b1),
        .D(ws_r_i_1_n_0),
        .Q(ws),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
