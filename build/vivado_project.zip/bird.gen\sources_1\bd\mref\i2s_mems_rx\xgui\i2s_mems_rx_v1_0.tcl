# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "ACC_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "CLK_HZ" -parent ${Page_0}
  ipgui::add_param $IPINST -name "FIFO_LOGDEPTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SAMPLE_HZ" -parent ${Page_0}


}

proc update_PARAM_VALUE.ACC_W { PARAM_VALUE.ACC_W } {
	# Procedure called to update ACC_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ACC_W { PARAM_VALUE.ACC_W } {
	# Procedure called to validate ACC_W
	return true
}

proc update_PARAM_VALUE.CLK_HZ { PARAM_VALUE.CLK_HZ } {
	# Procedure called to update CLK_HZ when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CLK_HZ { PARAM_VALUE.CLK_HZ } {
	# Procedure called to validate CLK_HZ
	return true
}

proc update_PARAM_VALUE.FIFO_LOGDEPTH { PARAM_VALUE.FIFO_LOGDEPTH } {
	# Procedure called to update FIFO_LOGDEPTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FIFO_LOGDEPTH { PARAM_VALUE.FIFO_LOGDEPTH } {
	# Procedure called to validate FIFO_LOGDEPTH
	return true
}

proc update_PARAM_VALUE.SAMPLE_HZ { PARAM_VALUE.SAMPLE_HZ } {
	# Procedure called to update SAMPLE_HZ when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SAMPLE_HZ { PARAM_VALUE.SAMPLE_HZ } {
	# Procedure called to validate SAMPLE_HZ
	return true
}


proc update_MODELPARAM_VALUE.CLK_HZ { MODELPARAM_VALUE.CLK_HZ PARAM_VALUE.CLK_HZ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CLK_HZ}] ${MODELPARAM_VALUE.CLK_HZ}
}

proc update_MODELPARAM_VALUE.SAMPLE_HZ { MODELPARAM_VALUE.SAMPLE_HZ PARAM_VALUE.SAMPLE_HZ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SAMPLE_HZ}] ${MODELPARAM_VALUE.SAMPLE_HZ}
}

proc update_MODELPARAM_VALUE.ACC_W { MODELPARAM_VALUE.ACC_W PARAM_VALUE.ACC_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ACC_W}] ${MODELPARAM_VALUE.ACC_W}
}

proc update_MODELPARAM_VALUE.FIFO_LOGDEPTH { MODELPARAM_VALUE.FIFO_LOGDEPTH PARAM_VALUE.FIFO_LOGDEPTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FIFO_LOGDEPTH}] ${MODELPARAM_VALUE.FIFO_LOGDEPTH}
}

