set_property SRC_FILE_INFO {cfile:D:/Vivado/bird/bird.srcs/constrs_1/imports/Vivado/inmp441_pmodb.xdc rfile:../../../bird.srcs/constrs_1/imports/Vivado/inmp441_pmodb.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:22 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN W14 IOSTANDARD LVCMOS33 } [get_ports {bclk}]; # PmodB 1
set_property src_info {type:XDC file:1 line:23 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN Y14 IOSTANDARD LVCMOS33 } [get_ports {ws}];   # PmodB 2
set_property src_info {type:XDC file:1 line:24 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN T11 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports {sd}]; # PmodB 3  (SD 闲置时弱下拉，INMP441 数据手册要求约 100k 下拉)
